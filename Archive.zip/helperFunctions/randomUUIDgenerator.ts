

export const idGenerator = () => {
    return String(Date.now())
}

